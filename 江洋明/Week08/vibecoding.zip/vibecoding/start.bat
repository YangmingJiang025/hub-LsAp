@echo off
REM === 深度研究助手 - Windows 启动入口(委托给 start.py)===
REM 实际逻辑在 start.py 里,这里只是为了双击方便。

setlocal
chcp 65001 >nul
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo [错误] Python 不在 PATH。
    echo 请安装 Python 3.10+ 或 Anaconda 后再试。
    echo 按任意键退出...
    pause >nul
    exit /b 1
)

python "%~dp0start.py"
exit /b %errorlevel%
