"""start.py - Python 版启动器(在 Windows cmd / PowerShell / Git Bash 都能用)。

用法:
    python start.py            # 完整启动流程
    python start.py --check    # 只做环境检查,不启动 Streamlit

为什么用 Python 而不是批处理:
    1. Python 对中文路径处理更鲁棒(cmd.exe 在某些 Windows 配置下对
       `E:\\个人\\AI学习\\...` 这类路径的 cd / streamlit 启动会出问题)
    2. Python 输出强制 UTF-8,中文不会乱码
    3. 任何异常都会被捕获并打印,不会"窗口闪过就消失"
    4. 失败步骤会等你按 Enter,不会自动关闭窗口
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

APP_DIR = Path(__file__).parent.resolve()


# === 强制 UTF-8(Windows 中文 cmd 默认 GBK,中文/特殊符号会报 UnicodeEncodeError)===
def _force_utf8_stdout() -> None:
    """Python 在 Windows 中文 cmd 下 stdout 默认 GBK,print 中文或 ✓ 这类字符会爆。

    必须在最早期(任何 print 之前)调用,优先用 reconfigure 拿到真 stdout,
    失败再用 TextIOWrapper 包一层。
    """
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        # Python 3.7+: reconfigure
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
                return
            except Exception:  # noqa: BLE001
                pass
        # 兜底: 用 io.TextIOWrapper 替换
        try:
            import io
            buf = getattr(stream, "buffer", None)
            if buf is not None:
                wrapper = io.TextIOWrapper(buf, encoding="utf-8", errors="replace", line_buffering=True)
                setattr(sys, stream_name, wrapper)
        except Exception:  # noqa: BLE001
            pass


_force_utf8_stdout()


def _wait(msg: str = "\n按 Enter 退出...") -> None:
    try:
        input(msg)
    except EOFError:
        pass


def _looks_like_placeholder(value: str) -> bool:
    """判断 .env 里的某个值是不是占位符。"""
    if not value:
        return True
    v = value.strip().lower()
    if not v or v in {"sk-xxx", "your_key_here", "changeme"}:
        return True
    # 检查 key 后面是否大部分都是占位
    if re.match(r"^sk-[0-9a-f]{8,}$", v):
        return False  # 看着像真实 key
    return False


def _check_env_content(env_path: Path) -> list[str]:
    """检查 .env 文件中是否缺失必需 key 或仍是占位符。返回问题列表。"""
    required = ["BOCHA_API_KEY", "DEEPSEEK_API_KEY"]
    issues: list[str] = []
    if not env_path.exists():
        issues.append(".env 文件不存在")
        return issues
    content = env_path.read_text(encoding="utf-8")
    for key in required:
        m = re.search(rf"^{key}\s*=\s*(.*?)\s*$", content, re.M)
        if not m:
            issues.append(f"缺少 {key}= 这一行")
            continue
        value = m.group(1).strip()
        if _looks_like_placeholder(value):
            issues.append(f"{key} 仍是占位符或为空")
    return issues


def _setup_env() -> int:
    """确保 .env 文件存在且 key 已填。返回 0=继续, 1=用户需补充并退出。"""
    env_path = APP_DIR / ".env"
    example_path = APP_DIR / ".env.example"

    if not env_path.exists():
        if example_path.exists():
            print(f"[2/4] .env 不存在,正在从 .env.example 复制...")
            shutil.copy2(example_path, env_path)
            print(f"      .env 已创建于: {env_path}")
            print()
            print("=" * 60)
            print("!  请先用记事本打开 .env 文件,                      !")
            print("!  填入 BOCHA_API_KEY 与 DEEPSEEK_API_KEY,         !")
            print("!  然后再次运行 python start.py                     !")
            print("=" * 60)
            _wait()
            return 1
        else:
            print("[错误] .env 和 .env.example 都不存在,项目文件不完整。")
            _wait()
            return 1

    issues = _check_env_content(env_path)
    if issues:
        print(f"[警告] .env 文件有问题:")
        for it in issues:
            print(f"      - {it}")
        print()
        print("      请用记事本打开 .env 修改后保存,再运行本脚本。")
        print(f"      .env 路径: {env_path}")
        _wait()
        return 1

    print(f"[2/4] .env 已就绪({env_path})。")
    return 0


def _check_deps() -> int:
    """检查关键依赖,缺失则 pip install。"""
    print(f"[3/4] 检查依赖...")
    missing: list[str] = []
    for mod in ("streamlit", "langchain", "langchain_openai"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if not missing:
        print(f"      streamlit / langchain / langchain_openai 已就绪。")
        return 0

    print(f"      缺失: {', '.join(missing)}")
    print(f"      正在执行: pip install -r requirements.txt")
    print()
    ret = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
        cwd=str(APP_DIR),
    )
    if ret.returncode != 0:
        print()
        print("[错误] 依赖安装失败!")
        print()
        print("       常见原因:")
        print("         1) 网络问题 - 切换镜像源:")
        print(f"            pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt")
        print("         2) pip 太旧 - 升级:")
        print(f"            python -m pip install --upgrade pip")
        _wait()
        return 1
    print()
    print("[完成] 依赖安装完成。")
    return 0


def _run_streamlit() -> int:
    print()
    print("=" * 60)
    print("  启动 Streamlit Web UI")
    print("  默认地址: http://localhost:8501")
    print()
    print("  ⚠  如果浏览器没有自动打开,")
    print("     请手动复制上面的地址到浏览器访问。")
    print()
    print("  按 Ctrl+C 停止服务。")
    print("=" * 60)
    print()
    try:
        ret = subprocess.run(
            [sys.executable, "-m", "streamlit", "run", "app.py"],
            cwd=str(APP_DIR),
        )
        return ret.returncode
    except KeyboardInterrupt:
        print("\n[中断] 用户按 Ctrl+C 终止服务。")
        return 0
    except FileNotFoundError as e:
        print(f"\n[错误] 找不到 streamlit: {e}")
        _wait()
        return 1


def main() -> int:
    only_check = "--check" in sys.argv
    print()
    print("=" * 60)
    print(f"  深度研究助手 - Python 启动器")
    print(f"  工作目录: {APP_DIR}")
    if only_check:
        print(f"  模式: 仅检查环境,不启动 Streamlit")
    print("=" * 60)
    print()

    # ===== 1. Python =====
    print(f"[1/4] Python {sys.version.split()[0]} 已就绪。")

    # ===== 2. .env =====
    rc = _setup_env()
    if rc != 0:
        return rc

    # ===== 3. 依赖 =====
    rc = _check_deps()
    if rc != 0:
        return rc

    if only_check:
        print()
        print("=" * 60)
        print("  [OK] 环境检查全部通过。可以运行 python start.py 启动。")
        print("=" * 60)
        return 0

    # ===== 4. 启动 Streamlit =====
    rc = _run_streamlit()
    return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  # noqa: BLE001
        print(f"\n[未捕获异常] {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        _wait()
        sys.exit(1)
