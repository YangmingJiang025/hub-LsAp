"""core/agent.py - ReAct Agent 编排(适配 langchain 1.x create_agent API)。

DeepResearch 类把以下几件事打包:
    1. 构建 DeepSeek LLM(ChatOpenAI 兼容协议)
    2. 调用 langchain.agents.create_agent(model=llm, tools=..., system_prompt=...)
    3. 通过 stream() 迭代,逐步把进度写进 storage.process.json
    4. 解析 Final Answer JSON,触发 report 渲染

注意:
    - langchain 1.x 移除了旧的 AgentExecutor / create_react_agent,
      改用 create_agent 返回的 CompiledStateGraph
    - 不再有显式 ReAct 模板;agent 内部用 LangGraph 状态机循环
    - 进度追踪改用消息流解析:遍历 messages 列表,识别 AIMessage(tool_calls) 与 ToolMessage
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from langchain.agents import create_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI

from core.callbacks import process_new_messages
from core.prompts import REACT_SYSTEM_INSTRUCTION
from core.report import render_final_report
from core.storage import (
    ResearchStorage,
    STATUS_COMPLETED,
    STATUS_FAILED,
)
from core import tools as core_tools

logger = logging.getLogger(__name__)


# === LLM 工厂 ===
def build_llm() -> BaseChatModel:
    """构造 DeepSeek LLM(走 OpenAI 兼容协议)。"""
    api_key = os.getenv("DEEPSEEK_API_KEY", "")
    base_url = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
    model = os.getenv("DEEPSEEK_MODEL", "deepseek-v4-flash")
    timeout = int(os.getenv("LLM_REQUEST_TIMEOUT", "120"))
    retries = int(os.getenv("LLM_RETRIES", "3"))

    if not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY 未配置,请检查 .env 文件")

    return ChatOpenAI(
        model=model,
        openai_api_key=api_key,
        openai_api_base=base_url,
        max_tokens=8000,
        temperature=0.3,
        request_timeout=timeout,
        max_retries=retries,
    )


# === JSON Final Answer 解析(DeepSeek 鲁棒)===
def parse_final_answer(text: str) -> dict | None:
    """从 agent 的最终消息内容里抠 JSON dict。

    容忍:
        - ```json ... ``` 包裹
        - 前置 / 后置解释文字
        - 单引号 / 双引号混杂
        - 空字符串 / None
    """
    if not text:
        return None
    text = text.strip()

    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, count=1, flags=re.IGNORECASE)
        text = re.sub(r"```\s*$", "", text, count=1)
    text = text.strip()

    try:
        return json.loads(text)
    except Exception:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        snippet = text[start : end + 1]
        try:
            return json.loads(snippet)
        except Exception:
            pass

    if start != -1 and end != -1:
        snippet = text[start : end + 1].replace("'", '"')
        try:
            return json.loads(snippet)
        except Exception:
            pass

    logger.warning("Final Answer 解析失败: %s", text[:200])
    return None


# === 状态对象 ===
@dataclass
class ResearchResult:
    """单次研究的最终结果。"""

    rid: str
    dir_path: str
    topic: str
    status: str
    error: Optional[str] = None
    raw_output: str = ""
    final_answer: Optional[dict] = None
    report_markdown: str = ""


# === 进度记录已迁移到 core.callbacks.process_new_messages ===


# === DeepResearch 编排 ===
@dataclass
class DeepResearch:
    """单次深度研究编排器。"""

    output_root: Path
    config: dict = field(default_factory=dict)

    DEFAULT_MAX_ITERATIONS = 5

    def run(self, topic: str) -> ResearchResult:
        """执行一次完整研究流程。"""
        storage = ResearchStorage.create(self.output_root, topic)
        storage.mark_running(self.config)
        logger.info("研究启动 rid=%s topic=%r", storage.dir_path.name, topic)

        try:
            llm = build_llm()
        except Exception as e:  # noqa: BLE001
            storage.mark_failed(f"LLM 初始化失败: {e}")
            return ResearchResult(
                rid=storage.dir_path.name,
                dir_path=str(storage.dir_path),
                topic=topic,
                status=STATUS_FAILED,
                error=str(e),
            )

        # 注入工具 context
        core_tools.set_context(storage, llm)

        try:
            agent = create_agent(
                model=llm,
                tools=core_tools.TOOLS,
                system_prompt=REACT_SYSTEM_INSTRUCTION,
                debug=False,
            )

            # === 流式执行 + 实时进度 ===
            storage.append_step({"kind": "agent_start", "topic": topic})

            last_msg_count = 0
            step_counter = [0]
            final_state: dict = {}

            try:
                for event in agent.stream(
                    {"messages": [{"role": "user", "content": topic}]},
                    stream_mode="values",
                ):
                    # event 是一个完整 state 快照
                    msgs = event.get("messages") or []
                    last_msg_count = process_new_messages(
                        storage=storage,
                        messages=msgs,
                        last_msg_count=last_msg_count,
                        step_counter=step_counter,
                    )
                    final_state = event
            except Exception as e:  # noqa: BLE001
                logger.exception("agent stream 执行失败")
                storage.append_step({"kind": "agent_error", "error": str(e)[:300]})
                storage.mark_failed(f"agent 执行失败: {e}")
                return ResearchResult(
                    rid=storage.dir_path.name,
                    dir_path=str(storage.dir_path),
                    topic=topic,
                    status=STATUS_FAILED,
                    error=str(e),
                )

            # === 解析 Final Answer ===
            messages = final_state.get("messages") or []
            raw_output = ""
            if messages:
                last_msg = messages[-1]
                raw_output = getattr(last_msg, "content", "") or ""

            storage.append_step({"kind": "agent_end", "message_count": len(messages)})
            final = parse_final_answer(raw_output)

            # === 渲染报告 ===
            markdown = render_final_report(
                storage=storage,
                topic=topic,
                final_answer=final,
                raw_output=raw_output,
            )
            storage.write_report(markdown)
            storage.mark_completed()
            logger.info("研究完成 rid=%s", storage.dir_path.name)
            return ResearchResult(
                rid=storage.dir_path.name,
                dir_path=str(storage.dir_path),
                topic=topic,
                status=STATUS_COMPLETED,
                raw_output=raw_output,
                final_answer=final,
                report_markdown=markdown,
            )

        finally:
            core_tools.clear_context()
