"""core/tools.py - ReAct agent 的 4 个工具。

工具集:
    1. web_search       调用 Bocha AI 搜索(返回带编号的格式化结果)
    2. fetch_url        针对一个 URL 拉取更详细摘要
    3. record_finding   把一条事实登记到黑板(findings.json)
    4. extract_facts    从一个 URL 的摘要中抽取结构化事实(内部调 LLM)

依赖:
    - httpx        Bocha API 调用
    - langchain    @tool 装饰器
    - core.storage  持久化(每个工具都需要)
    - core.prompts  extract_facts 子 prompt

线程模型:
    - 所有工具都是普通函数,ReAct agent 在后台线程顺序调用
    - 内部用 module 级 _storage / _llm 持有当前研究的 context
    - 通过 set_context() 注入,clear_context() 在研究结束后清理
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Optional

import httpx
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import tool

from core.prompts import EXTRACT_FACTS_PROMPT
from core.storage import ResearchStorage

logger = logging.getLogger(__name__)

# === Module-level context(由 agent.set_context 注入) ===
_storage: Optional[ResearchStorage] = None
_llm: Optional[BaseChatModel] = None


def set_context(storage: ResearchStorage, llm: BaseChatModel) -> None:
    """注入当前研究的 storage 和 LLM。agent.py 在每次 run() 开始时调用。"""
    global _storage, _llm
    _storage = storage
    _llm = llm


def clear_context() -> None:
    global _storage, _llm
    _storage = None
    _llm = None


def _require_storage() -> ResearchStorage:
    if _storage is None:
        raise RuntimeError("tools.set_context() 未调用,storage 未注入")
    return _storage


def _require_llm() -> BaseChatModel:
    if _llm is None:
        raise RuntimeError("tools.set_context() 未调用,LLM 未注入")
    return _llm


# === Bocha API 客户端 ===
def _bocha_search(query: str, count: int = 10) -> dict:
    """调 Bocha AI 搜索接口,返回原始 JSON dict。

    失败时返空 dict,不抛异常(让 agent 自己处理)。
    """
    api_key = os.getenv("BOCHA_API_KEY", "")
    base_url = os.getenv("BOCHA_BASE_URL", "https://api.bocha.cn/v1/web-search")
    if not api_key:
        logger.warning("BOCHA_API_KEY 未配置")
        return {}

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {"query": query, "summary": True, "count": min(count, 50)}

    try:
        with httpx.Client(timeout=30) as client:
            resp = client.post(base_url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            logger.info("Bocha 搜索成功 query=%r count=%d", query, count)
            return data
    except httpx.HTTPError as e:
        logger.error("Bocha 搜索失败: %s", e)
        return {}
    except Exception as e:  # noqa: BLE001
        logger.exception("Bocha 搜索异常: %s", e)
        return {}


def _parse_bocha_results(data: dict) -> list[dict]:
    """从 Bocha 响应中抽出 webPages 列表。

    Bocha 实际响应结构(参考文档):
        {
            "code": 200,
            "data": {
                "webPages": {"value": [{"name", "url", "snippet", "summary", ...}, ...]},
                ...
            }
        }
    """
    if not data:
        return []
    payload = data.get("data") or {}
    web = payload.get("webPages") or {}
    value = web.get("value") or []
    out: list[dict] = []
    for item in value:
        out.append(
            {
                "title": item.get("name") or item.get("title", ""),
                "url": item.get("url", ""),
                "snippet": item.get("snippet", ""),
                "summary": item.get("summary", ""),
            }
        )
    return out


def _register_sources(storage: ResearchStorage, results: list[dict]) -> dict[str, int]:
    """把搜索结果里的 URL 全部 upsert 到 sources.json,返回 {url: id} 映射。"""
    url_to_id: dict[str, int] = {}
    for r in results:
        url = r.get("url")
        if not url:
            continue
        sid = storage.upsert_source(
            {
                "url": url,
                "title": r.get("title", ""),
                "snippet": r.get("snippet", ""),
                "summary": r.get("summary", ""),
            }
        )
        url_to_id[url] = sid
    return url_to_id


def _format_results_for_agent(results: list[dict], url_to_id: dict[str, int]) -> str:
    """把搜索结果格式化成给 ReAct agent 看的人类可读文本。

    编号 [1] [2] [3] 与 sources.json 里的 id 一一对应,agent 用这个编号作为 source_id。
    """
    if not results:
        return "(无搜索结果)"

    blocks: list[str] = []
    for i, r in enumerate(results, start=1):
        url = r.get("url", "")
        sid = url_to_id.get(url, i)
        title = r.get("title", "(无标题)")
        snippet = r.get("snippet", "")
        summary = r.get("summary", "")
        block = (
            f"[{sid}] {title}\n"
            f"URL: {url}\n"
            f"摘要: {snippet[:200] if snippet else '(无)'}"
        )
        if summary and summary != snippet:
            block += f"\n详细: {summary[:400]}"
        blocks.append(block)
    return "\n\n---\n\n".join(blocks)


# === 工具 1: web_search ===
@tool
def web_search(query: str, count: int = 10) -> str:
    """调用 Bocha AI 网页搜索,返回与 query 最相关的前若干条结果。

    Args:
        query: 搜索关键词或问句(中文/英文均可)
        count: 返回条数(默认 10,最大 50)

    Returns:
        格式化字符串: 每个结果包含 [编号]、标题、URL、摘要。
        编号是来源 ID,后续 record_finding 时用此 ID 引用。

    Example:
        Action: web_search
        Action Input: {"query": "2026 AI Agent 行业趋势", "count": 10}
    """
    storage = _require_storage()
    data = _bocha_search(query, count)
    results = _parse_bocha_results(data)
    if not results:
        return f"搜索「{query}」未返回结果。"
    url_to_id = _register_sources(storage, results)
    formatted = _format_results_for_agent(results, url_to_id)
    storage.append_step(
        {
            "kind": "tool",
            "tool": "web_search",
            "input": {"query": query, "count": count},
            "output_count": len(results),
        }
    )
    return formatted


# === 工具 2: fetch_url ===
@tool
def fetch_url(url: str) -> str:
    """获取一个 URL 的更详细摘要。

    实现:用 Bocha 搜索接口,把 URL 作为 query 提交,从返回结果中匹配
    同一 URL 的页面,提取其 summary 字段。
    若该 URL 已在 sources.json 里,优先返回那里已有的 summary。

    Args:
        url: 目标网页的完整 URL

    Returns:
        该页面的标题 + 摘要 + URL;若获取失败返回错误信息。
    """
    storage = _require_storage()

    # 已在 sources.json → 直接返回
    for sid, src in enumerate(storage.get_sources(), start=1):
        if src.get("url") == url:
            title = src.get("title", "")
            summary = src.get("summary") or src.get("snippet", "")
            out = f"[{sid}] {title}\nURL: {url}\n摘要: {summary[:500] or '(无)'}"
            storage.append_step({"kind": "tool", "tool": "fetch_url", "input": {"url": url}, "output_count": 1})
            return out

    # 没找到 → 用 Bocha 搜一下
    data = _bocha_search(url, count=5)
    results = _parse_bocha_results(data)
    matched = next((r for r in results if r.get("url") == url), None)
    if matched is None and results:
        matched = results[0]  # 退而求其次取第一条
    if matched is None:
        storage.append_step({"kind": "tool", "tool": "fetch_url", "input": {"url": url}, "error": "no_match"})
        return f"无法获取 {url} 的内容(Bocha 未匹配)。"

    sid = storage.upsert_source(
        {
            "url": matched.get("url", url),
            "title": matched.get("title", ""),
            "snippet": matched.get("snippet", ""),
            "summary": matched.get("summary", ""),
        }
    )
    storage.append_step(
        {"kind": "tool", "tool": "fetch_url", "input": {"url": url}, "output_count": 1}
    )
    summary = matched.get("summary") or matched.get("snippet", "")
    return f"[{sid}] {matched.get('title', '')}\nURL: {matched.get('url', url)}\n摘要: {summary[:500] or '(无)'}"


# === 工具 3: record_finding ===
@tool
def record_finding(
    claim: str,
    source_id: int,
    confidence_hint: str = "medium",
) -> str:
    """把一条核心事实登记到「黑板」,供最终报告引用。

    Args:
        claim: 一句话事实陈述,应当尽量具体、可被独立验证
        source_id: 来源编号(必须来自 web_search / fetch_url 返回中的 [N] 编号)
        confidence_hint: "high" / "medium" / "low"
            - high: 来自权威来源(官网、学术、知名媒体)
            - medium: 来自一般可信来源
            - low: 来源较弱或仅一处

    Returns:
        成功: "已登记 (来源 #[id])"  失败: 错误说明
    """
    storage = _require_storage()
    sources = storage.get_sources()
    if not (1 <= source_id <= len(sources)):
        return (
            f"❌ 来源编号 #{source_id} 不在当前来源列表(共 {len(sources)} 条)。"
            "请使用 web_search 或 fetch_url 获取该 URL 后再登记。"
        )
    href = confidence_hint.lower().strip()
    if href not in {"high", "medium", "low"}:
        href = "medium"

    src = sources[source_id - 1]
    storage.add_finding(
        {
            "claim": claim.strip(),
            "source_id": source_id,
            "source_url": src.get("url", ""),
            "source_title": src.get("title", ""),
            "confidence_hint": href,
        }
    )
    storage.append_step(
        {
            "kind": "tool",
            "tool": "record_finding",
            "input": {"claim": claim[:120], "source_id": source_id, "confidence_hint": href},
            "output_count": 1,
        }
    )
    return f"✓ 已登记 (来源 #{source_id} {src.get('title', '')})"


# === 工具 4: extract_facts ===
@tool
def extract_facts(url: str, focus: str) -> str:
    """从一个 URL 的摘要中,围绕指定焦点抽取 2~5 条结构化事实。

    本工具内部会:
        1) 获取该 URL 的摘要(若已在 sources.json 则直接用,否则走 Bocha 搜索补)
        2) 调 LLM 做信息抽取
        3) 返回 JSON 字符串

    注意: 本工具只抽取,不直接登记黑板;你看完结果后,需要再调用
    record_finding 把有价值的事实写到黑板。

    Args:
        url: 目标 URL
        focus: 你想围绕哪个方面抽取(如「技术架构」「市场表现」「用户评价」)

    Returns:
        JSON 字符串, 形如 '[{"claim":"...","evidence_quote":"..."}, ...]'
    """
    storage = _require_storage()
    llm = _require_llm()

    # 1) 拿摘要
    content = ""
    for src in storage.get_sources():
        if src.get("url") == url:
            content = src.get("summary") or src.get("snippet", "")
            break
    if not content:
        data = _bocha_search(url, count=5)
        for r in _parse_bocha_results(data):
            if r.get("url") == url:
                content = r.get("summary") or r.get("snippet", "")
                break
    if not content:
        storage.append_step(
            {"kind": "tool", "tool": "extract_facts", "input": {"url": url, "focus": focus}, "error": "no_content"}
        )
        return "[]"

    # 2) 调 LLM 抽取
    prompt = EXTRACT_FACTS_PROMPT.format(focus=focus, content=content[:3000])
    try:
        resp = llm.invoke(prompt)
        text = getattr(resp, "content", str(resp))
    except Exception as e:  # noqa: BLE001
        logger.exception("extract_facts LLM 调用失败: %s", e)
        storage.append_step(
            {"kind": "tool", "tool": "extract_facts", "input": {"url": url, "focus": focus}, "error": str(e)}
        )
        return "[]"

    # 3) 清洗: 提取 JSON 数组
    cleaned = _extract_json_array(text)
    storage.append_step(
        {
            "kind": "tool",
            "tool": "extract_facts",
            "input": {"url": url, "focus": focus},
            "output_count": len(json.loads(cleaned)) if cleaned else 0,
        }
    )
    return cleaned


# === 内部: 从 LLM 输出中抠 JSON 数组 ===
def _extract_json_array(text: str) -> str:
    """容错地从 LLM 输出里抽出 JSON 数组子串。

    LLM 经常在 JSON 前后包 ```json ``` 或加杂解释,这里尽量鲁棒。
    """
    text = (text or "").strip()
    # 去掉代码块标记
    if text.startswith("```"):
        # 去掉首尾 ``` / ```json
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip("`").strip()
    # 直接就是数组
    if text.startswith("["):
        end = text.rfind("]")
        if end != -1:
            return text[: end + 1]
    # 找第一个 [ 与最后一个 ]
    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end != -1 and end > start:
        return text[start : end + 1]
    return "[]"


# === 导出:工具列表(供 agent.py 注册)===
TOOLS = [web_search, fetch_url, record_finding, extract_facts]
