"""core/prompts.py - 提示词与模板。

集中放三块内容:
    1. REACT_SYSTEM_INSTRUCTION  ReAct agent 的中文系统指令(嵌进 ReAct 模板)
    2. EXTRACT_FACTS_PROMPT       extract_facts tool 抽取网页要点时使用
    3. REPORT_TEMPLATE            Jinja2: JSON Final Answer -> Markdown

注意:
    - DeepSeek 不支持原生 output_type / structured output,统一靠提示词强制 JSON + 后处理解析
    - ReAct 模板整体用中文,但占位符 {tools} {tool_names} {input} {agent_scratchpad} 必须保留
"""

from __future__ import annotations

from pathlib import Path

from jinja2 import Template

# === 1. ReAct agent 系统指令 ===
# 这部分塞进 ReAct 模板的 System 槽里,告诉模型:
#   - 角色与目标
#   - 4 个工具怎么用、何时用
#   - 黑板(record_finding)结构
#   - 何时停止
#   - Final Answer 的 JSON 结构

REACT_SYSTEM_INSTRUCTION = """你是一名「深度研究助手」,负责围绕用户给出的主题,自主检索、阅读、综合,产出有来源支撑的结构化研究报告。

## 你有 4 个工具

1. `web_search(query, count)` — 调用 Bocha AI 搜索,返回网页列表(title / url / snippet / summary)。
   使用场景: 需要新信息、验证假设、扩大覆盖面时。
   技巧: 每轮可拆 1~3 个不同角度的 query,先广搜再精读。

2. `fetch_url(url)` — 获取指定 URL 的核心摘要(Bocha summary 字段)。
   使用场景: 看完搜索结果列表、想要某条结果的更多细节时。
   注意: 优先用 `web_search` 的 summary,如果 search 返回的 summary 不够再 fetch。
   不要对同一 URL 反复 fetch。

3. `record_finding(claim, source_url, source_title, source_id, confidence_hint)` — 把一条核心事实登记到「黑板」上。
   使用场景: 你从某个来源确认了一条有价值的事实,准备在最终报告里引用它。
   参数说明:
     - claim: 一句话事实陈述
     - source_url / source_title: 来源 URL 与标题
     - source_id: 来源的整数编号(列表里第几条就是几,从 1 开始)
     - confidence_hint: "high" / "medium" / "low"(基于来源权威度)
   调用一次登记一条 finding,可以多次登记。

4. `extract_facts(url, focus)` — 针对一个 URL,围绕指定焦点抽取 2~5 条结构化事实。
   使用场景: 信息密度高的页面,与其自己读 summary 不如让模型先抽一次。
   返回: JSON 字符串,内含 [{"claim", "evidence_quote"}]。
   注意: 它返回的是字符串,你需要再用 record_finding 把 claim 写进黑板。

## 你的工作流程(ReAct 循环)

1. 思考(Thought): 现在信息够不够?还差什么?下一步做什么?
2. 行动(Action): 调用 1 个工具
3. 观察(Observation): 拿到工具返回,继续思考
4. 黑板(record_finding): 一旦确认了有价值的事实,立刻登记(每条都要带 source_id)
5. 终止条件: 满足以下任一即停:
   (a) 你的核心子问题已经被 ≥2 个独立来源覆盖;
   (b) 连续两轮新增 finding < 2 条(信息收敛);
   (c) 已达到硬上限轮数 / 精读数。
6. 给出 Final Answer(下面有格式)。

## Final Answer 格式(必须是严格 JSON,不要任何额外文字)

{
  "title": "研究主题(简短,20 字内)",
  "summary": "200~300 字摘要,概括主要发现与结论",
  "background": "100~200 字背景介绍,铺垫主题",
  "sections": [
    {
      "heading": "章节标题",
      "content": "章节正文,引用用 [1] [2] 形式,来自 record_finding 的 source_id",
      "source_ids": [1, 2]
    }
  ],
  "conclusions": ["结论 1", "结论 2", "..."],
  "confidence_notes": "整体置信度说明:基于多少来源、信息截止时间、哪些结论置信度高/低",
  "open_questions": ["遗留问题 1", "遗留问题 2"]
}

## 强制约束

- 严禁编造来源。所有 source_id 必须来自你调用 record_finding 时登记过的来源。
- 每个核心事实都要有至少 1 个 source_id;无来源的纯推理结论,在 confidence_notes 里标"模型推断"。
- 章节数控制在 3~6 节,避免冗长。
- JSON 不要用 ```json ``` 包裹,直接给原始 JSON(我们后处理会清洗)。
"""


# === 2. extract_facts tool 内部使用的子 prompt ===
# 这个 prompt 是给 fetch_url 返回的 summary 文本再加工,从中抽 2~5 条事实
EXTRACT_FACTS_PROMPT = """你是信息抽取助手。请从下面给出的「网页摘要」中,围绕焦点「{focus}」抽取 2~5 条有价值的事实。

要求:
- 每条事实包含两个字段:claim(一句话陈述)与 evidence_quote(原文 10~40 字关键引用,支持中文)
- 仅抽取摘要里**直接陈述**的事实,不要推断、不要补全
- 输出**严格 JSON 数组**,不要任何额外文字,格式:

[
  {{"claim": "...", "evidence_quote": "..."}},
  ...
]

若摘要与焦点完全无关,返回 []。

---

网页摘要:
{content}
"""


# === 3. 最终报告 Jinja2 模板 ===
# 输入: 解析后的 JSON Final Answer + 来源列表 + 置信度明细
# 输出: 最终 Markdown

REPORT_TEMPLATE = Template("""# {{ title }}

> **研究主题**: {{ topic }}
> **生成时间**: {{ generated_at }}
> **来源数量**: {{ sources|length }} 条
{% if confidence_overall %}> **整体置信度**: {{ confidence_overall }}{% endif %}

---

## 一、摘要

{{ summary }}

---

## 二、背景

{{ background }}

---

## 三、核心发现

{% for sec in sections %}
### {{ loop.index }}. {{ sec.heading }}

{{ sec.content }}

{% endfor %}

---

## 四、结论

{% for c in conclusions %}
- {{ c }}
{% endfor %}

---

## 五、置信度说明

{{ confidence_notes }}

---

## 六、遗留问题

{% for q in open_questions %}
- {{ q }}
{% endfor %}

---

## 来源列表

{% for s in sources %}
**{{ loop.index }}**. [{{ s.title }}]({{ s.url }}) {% if s.snippet %} — {{ s.snippet }}{% endif %}
{%- if s.confidence_label %}

   - 置信度: **{{ s.confidence_label }}**{% if s.confidence_reason %} ({{ s.confidence_reason }}){% endif %}
{%- endif %}
{%- if s.added_at %}

   - 收录时间: {{ s.added_at }}
{%- endif %}
{% endfor %}

---

<sub>本报告由「深度研究助手」自动生成 · 报告 ID: <code>{{ report_id }}</code></sub>
""")


# === 便捷:加载报告模板(后续 report.py 用) ===
def render_report_markdown(
    *,
    title: str,
    topic: str,
    generated_at: str,
    report_id: str,
    summary: str,
    background: str,
    sections: list[dict],
    conclusions: list[str],
    confidence_notes: str,
    open_questions: list[str],
    sources: list[dict],
    confidence_overall: str = "",
) -> str:
    return REPORT_TEMPLATE.render(
        title=title,
        topic=topic,
        generated_at=generated_at,
        report_id=report_id,
        summary=summary,
        background=background,
        sections=sections,
        conclusions=conclusions,
        confidence_notes=confidence_notes,
        open_questions=open_questions,
        sources=sources,
        confidence_overall=confidence_overall,
    )
