"""core/report.py - 综合 + 引用校验 + 置信度 + 报告渲染。

职责:
    1. 校验 Final Answer 中的 source_id 是否在 sources.json 里合法
    2. 为每个 source 打置信度标签 (high/medium/low)
    3. 用 Jinja2 把结构化结果渲染成 Markdown
    4. Final Answer 解析失败的兜底:用 raw_output 写一份降级报告
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Optional
from urllib.parse import urlparse

from core.prompts import render_report_markdown
from core.storage import ResearchStorage

logger = logging.getLogger(__name__)


# === 1. URL 域名权威性启发式 ===
# 用于置信度算法的「质量加权」

_TRUSTED_DOMAINS = (
    # 中文权威
    "baike.baidu.com",
    "zh.wikipedia.org",
    "wiki.hk.xhamster.com",
    # 政府 / 学术
    ".gov.cn",
    ".gov",
    ".edu.cn",
    ".edu",
    ".ac.cn",
    ".ac.uk",
    # 通用权威
    "wikipedia.org",
    "who.int",
    "nature.com",
    "science.org",
    "arxiv.org",
    "github.com",
    # 主流媒体(白名单)
    "reuters.com",
    "bbc.com",
    "bbc.co.uk",
    "nytimes.com",
    "wsj.com",
    "bloomberg.com",
    "ft.com",
    "theguardian.com",
    "economist.com",
    # 中文主流
    "people.com.cn",
    "xinhuanet.com",
    "qq.com",
    "163.com",
    "sina.com.cn",
    "sohu.com",
    "ifeng.com",
)

_LOW_QUALITY_PATTERNS = (
    # 常见内容农场 / SEO 站
    "-seo",
    "seo.",
    "click.",
    "ad.",
    "ads.",
    "tracker.",
    "spam.",
    "free-",
    "cheap-",
    "discount-",
    "casino",
    "porn",
    "xxx",
)


def _domain_of(url: str) -> str:
    try:
        host = urlparse(url).netloc.lower()
        return host[4:] if host.startswith("www.") else host
    except Exception:  # noqa: BLE001
        return ""


def _is_trusted(url: str) -> bool:
    host = _domain_of(url)
    if not host:
        return False
    if any(host == d or host.endswith("." + d.lstrip(".")) for d in _TRUSTED_DOMAINS):
        return True
    # 二级 .gov.cn / .edu.cn 子域也算
    if host.endswith(".gov.cn") or host.endswith(".edu.cn"):
        return True
    return False


def _is_low_quality(url: str) -> bool:
    host = _domain_of(url)
    full = (host + url).lower()
    return any(pat in full for pat in _LOW_QUALITY_PATTERNS)


# === 2. 单 source 的置信度打分 ===
def score_source(url: str, other_citing_source_ids: list[int], all_findings: list[dict]) -> dict:
    """对单个来源打置信度。

    算法 (Q12 决策 D = B + C 组合):
        base    = "high" 若有 ≥2 个独立来源同向 / "medium" 若 1 个 / "low" 若 0
        bonus   = 权威域名 +1, 低质量域名 -1
        final   = clamp(high/medium/low)

    Args:
        url:                  本来源的 URL
        other_citing_source_ids: 与本来源「同 claim」的其他来源 id 列表
        all_findings:         findings 黑板全文(用于查询同 claim)

    Returns:
        {"confidence_label": "high"/"medium"/"low",
         "confidence_reason": "..."}
    """
    base = "medium"
    n = len(other_citing_source_ids)
    if n >= 2:
        base = "high"
    elif n == 0:
        base = "low"

    if _is_trusted(url):
        if base == "low":
            base = "medium"
        reason_suffix = "权威域名加权"
    elif _is_low_quality(url):
        if base == "high":
            base = "medium"
        elif base == "medium":
            base = "low"
        reason_suffix = "低质量域名减分"
    else:
        reason_suffix = "一般域名"

    if n >= 2:
        reason = f"有 {n} 个独立来源同向 + {reason_suffix}"
    elif n == 1:
        reason = f"1 个来源支撑 + {reason_suffix}"
    else:
        reason = f"无同向来源 + {reason_suffix}"

    return {"confidence_label": base, "confidence_reason": reason}


# === 3. 从 findings 黑板统计「同 claim 共现」 ===
def _co_citation_graph(findings: list[dict]) -> dict[int, set[int]]:
    """返回 {source_id: {其他同时被引用的 source_id}}。

    「同 claim」: 同一 source_id 对应多个 finding 不算;我们粗略地用
    finding 列表里的所有 source_id 视为「同一研究主题」下的相互支撑。
    """
    all_ids = sorted({f.get("source_id") for f in findings if isinstance(f.get("source_id"), int)})
    others = set(all_ids)
    return {sid: others - {sid} for sid in all_ids}


# === 4. 给 sources.json 里每条记录打分 ===
def annotate_sources_with_confidence(storage: ResearchStorage) -> list[dict]:
    """读取 storage.sources + findings,返回带 confidence_label/reason 的 sources 列表(顺序不变)。"""
    sources = storage.get_sources()
    findings = storage.get_findings()
    co = _co_citation_graph(findings)

    out = []
    for idx, src in enumerate(sources, start=1):
        url = src.get("url", "")
        others = list(co.get(idx, set()))
        score = score_source(url, others, findings)
        new_src = dict(src)
        new_src["confidence_label"] = score["confidence_label"]
        new_src["confidence_reason"] = score["confidence_reason"]
        out.append(new_src)
    return out


# === 5. 校验 Final Answer 引用 ===
def validate_citations(final: dict, sources: list[dict]) -> tuple[dict, list[str]]:
    """校验 Final Answer 中所有 source_id 是否合法。

    Returns:
        (清理后的 final, warnings)

    规则:
        - source_id 越界(超出 1..N)→ 移除该 id,记 warning
        - section.content 中出现的 [N] 内联引用保留(渲染时不影响)
        - sections 缺失时补一个空 list
    """
    warnings: list[str] = []
    if not isinstance(final, dict):
        return final or {}, ["Final Answer 不是 dict,跳过校验"]

    n = len(sources)
    sections = final.get("sections") or []
    if not isinstance(sections, list):
        sections = []
        final["sections"] = sections

    cleaned_sections = []
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        ids = sec.get("source_ids") or []
        if not isinstance(ids, list):
            ids = []
        valid_ids = []
        for sid in ids:
            if isinstance(sid, int) and 1 <= sid <= n:
                valid_ids.append(sid)
            else:
                warnings.append(f"章节「{sec.get('heading', '?')}」中 source_id={sid} 越界,已剔除")
        sec["source_ids"] = valid_ids
        cleaned_sections.append(sec)

    final["sections"] = cleaned_sections

    # 兜底字段
    final.setdefault("title", "(未命名研究)")
    final.setdefault("summary", "")
    final.setdefault("background", "")
    final.setdefault("conclusions", [])
    final.setdefault("confidence_notes", "")
    final.setdefault("open_questions", [])
    if not isinstance(final["conclusions"], list):
        final["conclusions"] = [str(final["conclusions"])]
    if not isinstance(final["open_questions"], list):
        final["open_questions"] = [str(final["open_questions"])]

    return final, warnings


# === 6. 整体置信度判定 ===
def _overall_confidence(sources: list[dict]) -> str:
    """根据所有 sources 的 confidence_label 估算整体置信度。"""
    if not sources:
        return "低(无来源)"
    counts = {"high": 0, "medium": 0, "low": 0}
    for s in sources:
        counts[s.get("confidence_label", "medium")] += 1
    total = sum(counts.values())
    high_ratio = counts["high"] / total
    low_ratio = counts["low"] / total
    if high_ratio >= 0.6 and low_ratio <= 0.2:
        return f"高(高:{counts['high']} 中:{counts['medium']} 低:{counts['low']})"
    if low_ratio >= 0.5:
        return f"低(高:{counts['high']} 中:{counts['medium']} 低:{counts['low']})"
    return f"中(高:{counts['high']} 中:{counts['medium']} 低:{counts['low']})"


# === 7. 主入口: 渲染最终 Markdown ===
def render_final_report(
    *,
    storage: ResearchStorage,
    topic: str,
    final_answer: Optional[dict],
    raw_output: str = "",
) -> str:
    """把 Final Answer + sources + 置信度 渲染成 Markdown 报告,落盘到 report.md。"""
    sources = annotate_sources_with_confidence(storage)

    # 校验引用
    cleaned: dict
    warnings: list[str]
    if final_answer is None:
        cleaned, warnings = (
            {
                "title": topic[:20],
                "summary": "(Final Answer 未能解析为 JSON,以下是 agent 的原始输出。)",
                "background": "",
                "sections": [],
                "conclusions": [],
                "confidence_notes": "Final Answer 解析失败,报告为降级版本。",
                "open_questions": ["请人工补充本次研究的结构化结论。"],
            },
            ["Final Answer 不是合法 JSON,使用降级渲染。"],
        )
    else:
        cleaned, warnings = validate_citations(final_answer, sources)

    # 把 warnings 写进 process(便于 UI 看到)
    for w in warnings:
        storage.append_step({"kind": "validation_warning", "warning": w})

    # 给每个 section 加 confidence 标记 (哪些 section 没有 source_ids → 模型推断)
    sections_for_render = []
    for sec in cleaned.get("sections", []):
        sec_ids = sec.get("source_ids") or []
        if sec_ids:
            sec_labels = [sources[i - 1].get("confidence_label", "?") for i in sec_ids if 1 <= i <= len(sources)]
            inferred = "模型推断" if all(l == "low" for l in sec_labels) else ""
            heading_suffix = ""
            if inferred:
                heading_suffix = " *(模型推断 — 来源置信度均为低)*"
        else:
            heading_suffix = " *(模型推断 — 无来源)*"
        sections_for_render.append(
            {
                "heading": (sec.get("heading", "") or "未命名章节") + heading_suffix,
                "content": sec.get("content", ""),
                "source_ids": sec_ids,
            }
        )

    # 拼接 confidence_notes,加上引用警告
    confidence_notes = cleaned.get("confidence_notes", "")
    if warnings:
        confidence_notes += "\n\n### 校验警告\n\n" + "\n".join(f"- {w}" for w in warnings)
    if sources:
        confidence_notes += f"\n\n整体置信度: **{_overall_confidence(sources)}**"

    markdown = render_report_markdown(
        title=cleaned.get("title", topic[:20]),
        topic=topic,
        generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        report_id=storage.dir_path.name,
        summary=cleaned.get("summary", ""),
        background=cleaned.get("background", ""),
        sections=sections_for_render,
        conclusions=cleaned.get("conclusions", []),
        confidence_notes=confidence_notes.strip(),
        open_questions=cleaned.get("open_questions", []),
        sources=sources,
        confidence_overall=_overall_confidence(sources),
    )
    return markdown


# === 8. 简单的内容清理: 去掉 agent 可能多写的零碎 ===
_WHITESPACE_RE = re.compile(r"\n{3,}")


def cleanup_markdown(md: str) -> str:
    """规范化 markdown: 多余空行、尾部空白。"""
    md = _WHITESPACE_RE.sub("\n\n", md)
    return md.strip() + "\n"
