"""core 包 - 深度研究助手的核心业务模块。

子模块:
    storage     持久化(输出目录 + 4 文件 + 状态机)
    prompts     提示词 + Jinja2 报告模板
    tools       4 个 LangChain tool
    callbacks   进度回调(写 process.json)
    agent       ReAct Agent 编排
    report      综合 + 引用校验 + 置信度
"""
