"""core/storage.py - 持久化层。

职责:
    1. 创建单次研究的输出目录(时间戳 + 主题 slug)
    2. 读写 4 个文件: report.md / sources.json / process.json / findings.json
    3. 状态机: pending -> running -> completed / failed
    4. 原子写(临时文件 + rename,避免读到半截)
    5. 列出历史研究(供侧栏下拉)

依赖: 仅标准库 + python-dotenv
"""

from __future__ import annotations

import json
import re
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

# === 状态机常量 ===
STATUS_PENDING = "pending"
STATUS_RUNNING = "running"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"


# === 工具函数 ===
def slugify(text: str, max_len: int = 30) -> str:
    """从主题生成文件系统安全的 slug。

    中文保留,英文转小写、空格转下划线、剔除特殊字符。
    """
    text = text.strip()
    # 保留中文 / 英文 / 数字 / 空格 / 短横线 / 下划线
    text = re.sub(r"[^\w一-鿿 \-]", "", text)
    text = re.sub(r"[\s\-]+", "_", text).strip("_")
    text = text[:max_len] or "research"
    return text


def make_dir_name(topic: str) -> str:
    """生成 output 下的子目录名: 2026-09-10_143025_slug。"""
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    return f"{ts}_{slugify(topic)}"


# === 写盘: 原子化 JSON ===
def _atomic_write_json(path: Path, data: Any) -> None:
    """写到同目录 .tmp 文件,再 rename 替换(原子)。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    tmp.replace(path)


def _atomic_write_text(path: Path, text: str) -> None:
    """原子化写文本。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def _read_json(path: Path) -> Any:
    """读 JSON,文件不存在返回 None。"""
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


# === ResearchStorage: 单次研究的存储门面 ===
@dataclass
class ResearchStorage:
    """单次研究的存储门面。

    一个实例对应 output/下一次研究。
    内部用 threading.Lock 保护文件写,便于在后台线程里跑 agent + UI 轮询。

    4 个产物文件:
        report.md       最终结构化报告(Markdown)
        sources.json    来源列表 [{id, url, title, snippet, summary}]
        process.json     过程摘要 + 状态机
        findings.json   黑板快照:所有 record_finding 调用 + 引用校验
    """

    dir_path: Path
    topic: str
    started_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    # ----- 工厂 -----
    @classmethod
    def create(cls, output_root: Path, topic: str) -> "ResearchStorage":
        """创建新研究,生成目录并初始化 process.json。"""
        output_root.mkdir(parents=True, exist_ok=True)
        dir_name = make_dir_name(topic)
        dir_path = output_root / dir_name
        # 同秒冲突时加后缀
        suffix = 1
        while dir_path.exists():
            dir_path = output_root / f"{dir_name}__{suffix}"
            suffix += 1
        dir_path.mkdir(parents=True, exist_ok=False)

        store = cls(dir_path=dir_path, topic=topic)
        store._write_process(
            {
                "topic": topic,
                "status": STATUS_PENDING,
                "started_at": store.started_at,
                "updated_at": store.started_at,
                "steps": [],
                "error": None,
                "config": {},
            }
        )
        store._write_findings({"findings": [], "updated_at": store.started_at})
        store._write_sources({"sources": [], "updated_at": store.started_at})
        return store

    @classmethod
    def open(cls, dir_path: Path) -> "ResearchStorage":
        """打开已有研究目录。"""
        process = _read_json(dir_path / "process.json") or {}
        return cls(
            dir_path=dir_path,
            topic=process.get("topic", dir_path.name),
            started_at=process.get("started_at", ""),
        )

    # ----- 路径属性 -----
    @property
    def report_path(self) -> Path:
        return self.dir_path / "report.md"

    @property
    def sources_path(self) -> Path:
        return self.dir_path / "sources.json"

    @property
    def process_path(self) -> Path:
        return self.dir_path / "process.json"

    @property
    def findings_path(self) -> Path:
        return self.dir_path / "findings.json"

    # ----- 状态机 -----
    def mark_running(self, config: dict | None = None) -> None:
        with self._lock:
            data = self._read_process()
            data["status"] = STATUS_RUNNING
            data["updated_at"] = datetime.now().isoformat(timespec="seconds")
            if config:
                data["config"] = config
            self._write_process(data)

    def mark_completed(self) -> None:
        with self._lock:
            data = self._read_process()
            data["status"] = STATUS_COMPLETED
            data["updated_at"] = datetime.now().isoformat(timespec="seconds")
            data["finished_at"] = data["updated_at"]
            self._write_process(data)

    def mark_failed(self, error: str) -> None:
        with self._lock:
            data = self._read_process()
            data["status"] = STATUS_FAILED
            data["error"] = error
            data["updated_at"] = datetime.now().isoformat(timespec="seconds")
            data["finished_at"] = data["updated_at"]
            self._write_process(data)

    # ----- 进度追加 -----
    def append_step(self, step: dict) -> None:
        """append 一条过程记录 (由 callbacks 反复调用)。"""
        with self._lock:
            data = self._read_process()
            step["at"] = datetime.now().isoformat(timespec="seconds")
            data["steps"].append(step)
            data["updated_at"] = step["at"]
            self._write_process(data)

    # ----- 黑板 -----
    def add_finding(self, finding: dict) -> None:
        """record_finding tool 调用入口:append 一条 finding 到黑板。"""
        with self._lock:
            data = self._read_findings()
            # 同 source_id 重复时合并
            data["findings"].append(finding)
            data["updated_at"] = datetime.now().isoformat(timespec="seconds")
            self._write_findings(data)

    def get_findings(self) -> list[dict]:
        return list(self._read_findings().get("findings", []))

    # ----- 来源 -----
    def upsert_source(self, source: dict) -> int:
        """新增/更新一个来源,返回该来源在 sources.json 里的 1-based id。

        同一 URL 已存在则返回旧 id,新条目追加到末尾并返回新 id。
        """
        with self._lock:
            data = self._read_sources()
            url = source.get("url")
            sources = data.get("sources", [])
            for idx, item in enumerate(sources, start=1):
                if item.get("url") == url:
                    # 更新 title/snippet/summary 与元数据
                    for k, v in source.items():
                        item[k] = v
                    item["updated_at"] = datetime.now().isoformat(timespec="seconds")
                    data["sources"] = sources
                    data["updated_at"] = item["updated_at"]
                    self._write_sources(data)
                    return idx
            # 新增
            source.setdefault("added_at", datetime.now().isoformat(timespec="seconds"))
            sources.append(source)
            data["sources"] = sources
            data["updated_at"] = source["added_at"]
            self._write_sources(data)
            return len(sources)

    def get_sources(self) -> list[dict]:
        """按出现顺序返回来源列表(含隐式 id)。"""
        return list(self._read_sources().get("sources", []))

    # ----- 报告 -----
    def write_report(self, markdown: str) -> None:
        with self._lock:
            _atomic_write_text(self.report_path, markdown)

    def get_report(self) -> str:
        if not self.report_path.exists():
            return ""
        return self.report_path.read_text(encoding="utf-8")

    def get_process(self) -> dict:
        return self._read_process()

    # ----- 内部读 -----
    def _read_process(self) -> dict:
        return _read_json(self.process_path) or {}

    def _read_findings(self) -> dict:
        return _read_json(self.findings_path) or {"findings": []}

    def _read_sources(self) -> dict:
        return _read_json(self.sources_path) or {"sources": []}

    # ----- 内部写(不加锁,调用方负责锁)-----
    def _write_process(self, data: dict) -> None:
        _atomic_write_json(self.process_path, data)

    def _write_findings(self, data: dict) -> None:
        _atomic_write_json(self.findings_path, data)

    def _write_sources(self, data: dict) -> None:
        _atomic_write_json(self.sources_path, data)


# === 历史浏览 ===
def list_histories(output_root: Path) -> list[dict]:
    """列出 output/ 下所有已完成/失败/运行中的研究,按目录名倒序(最新在前)。

    返回: [{"dir_name": "...", "topic": "...", "status": "...", "started_at": "..."}, ...]
    """
    if not output_root.exists():
        return []
    items: list[dict] = []
    for child in sorted(output_root.iterdir(), reverse=True):
        if not child.is_dir():
            continue
        process = _read_json(child / "process.json")
        if not process:
            continue
        items.append(
            {
                "dir_name": child.name,
                "dir_path": str(child),
                "topic": process.get("topic", child.name),
                "status": process.get("status", STATUS_PENDING),
                "started_at": process.get("started_at", ""),
                "updated_at": process.get("updated_at", ""),
            }
        )
    return items
