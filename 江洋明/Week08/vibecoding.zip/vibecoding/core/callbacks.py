"""core/callbacks.py - 进度回调与消息处理。

langchain 1.x 的 create_agent 不再使用 BaseCallbackHandler 做精细进度回调,
而是直接 stream 整个 state。我们提供 `process_new_messages` 函数把新增的
message 列表转成 process.json 的一行 step。

保留 ProgressCallback 旧类以备扩展(未来若想接 LangSmith / 自定义 sink)。
"""

from __future__ import annotations

import json
import logging
import threading
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from core.storage import ResearchStorage

logger = logging.getLogger(__name__)


# === 工具函数 ===
def _short_repr(obj: Any, limit: int = 200) -> str:
    try:
        s = obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False)
    except Exception:  # noqa: BLE001
        s = str(obj)
    return s[:limit]


# === 核心:把 message 转成 step 写入 process.json ===
def process_new_messages(
    storage: ResearchStorage,
    messages: list[Any],
    last_msg_count: int,
    step_counter: list[int],
) -> int:
    """把 messages[last_msg_count:] 里的每条 message 转成 step 写入 storage。

    Args:
        storage: ResearchStorage 实例
        messages: 当前完整的 messages 列表
        last_msg_count: 上次已经处理过的消息条数
        step_counter: [当前步数](用 list 是为了在闭包里可变)

    Returns:
        新的 last_msg_count(供下次调用)
    """
    new_msgs = messages[last_msg_count:]
    for msg in new_msgs:
        try:
            if isinstance(msg, HumanMessage):
                storage.append_step(
                    {
                        "kind": "user_input",
                        "preview": (getattr(msg, "content", "") or "")[:200],
                    }
                )
            elif isinstance(msg, AIMessage):
                content = getattr(msg, "content", "") or ""
                tool_calls = getattr(msg, "tool_calls", None) or []
                if tool_calls:
                    step_counter[0] += 1
                    for tc in tool_calls:
                        storage.append_step(
                            {
                                "kind": "agent_action",
                                "step": step_counter[0],
                                "tool": tc.get("name", "?"),
                                "tool_input": _short_repr(tc.get("args", {})),
                                "thought_preview": content[:300] if content else "",
                            }
                        )
                elif content:
                    # AI 自己思考但没调工具
                    storage.append_step(
                        {
                            "kind": "agent_thought",
                            "step": step_counter[0] + 1,
                            "preview": content[:400],
                        }
                    )
            elif isinstance(msg, ToolMessage):
                storage.append_step(
                    {
                        "kind": "tool_end",
                        "tool": getattr(msg, "name", "?"),
                        "tool_call_id": getattr(msg, "tool_call_id", "?"),
                        "output_preview": _short_repr(getattr(msg, "content", ""), 300),
                    }
                )
            else:
                # 其他类型(SystemMessage 等),跳过
                pass
        except Exception as e:  # noqa: BLE001
            logger.warning("process_new_messages 单条失败: %s", e)
    return last_msg_count + len(new_msgs)


# === 旧版 ProgressCallback 兼容(预留扩展)===
class ProgressCallback(BaseCallbackHandler):
    """保留以便后续接 LangSmith / 自定义 sink。

    当前 agent.py 不直接调用它(用 stream + process_new_messages)。
    留着以备在不想 stream 全部 state 时,通过 invoke(config={"callbacks": [...]})
    接入。
    """

    raise_error: bool = False

    def __init__(self, storage: ResearchStorage) -> None:
        super().__init__()
        self.storage = storage
        self._lock = threading.Lock()
