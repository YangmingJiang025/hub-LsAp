"""app.py - Streamlit Web UI 入口。

布局 (Q30 + Q14 + Q21):
    [侧栏] 历史研究下拉
    [主区] 顶部表单(主题/预算/示例下拉)
            + 4 Tabs(进度 / 报告 / 来源 / 过程)

启动:
    streamlit run app.py
"""

from __future__ import annotations

import json
import logging
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

# === Windows UTF-8 兜底(CLAUDE.md 约定)===
try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

# === 加载 .env ===
from dotenv import load_dotenv

load_dotenv()

import streamlit as st  # noqa: E402

from core.agent import DeepResearch  # noqa: E402
from core.storage import (  # noqa: E402
    ResearchStorage,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_RUNNING,
    list_histories,
)


# === 路径常量 ===
APP_DIR = Path(__file__).parent
OUTPUT_ROOT = APP_DIR / "output"
EXAMPLES_PATH = APP_DIR / "configs" / "examples.json"
LOGS_DIR = APP_DIR / "logs"


# === 日志:写到 logs/app.log + stderr ===
LOGS_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOGS_DIR / "app.log", encoding="utf-8"),
        logging.StreamHandler(sys.stderr),
    ],
)
logger = logging.getLogger("vibecoding.app")


# === Streamlit 页面配置 ===
st.set_page_config(
    page_title="深度研究助手",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)


# === 加载示例主题 ===
@st.cache_data
def load_examples() -> list[dict]:
    if not EXAMPLES_PATH.exists():
        return []
    try:
        data = json.loads(EXAMPLES_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception as e:  # noqa: BLE001
        logger.warning("examples.json 加载失败: %s", e)
        return []


# === Session State 初始化 ===
def _init_state() -> None:
    defaults = {
        "research_running": False,
        "current_rid": None,
        "topic_input": "",
        "selected_example_idx": 0,
        "last_tick": 0.0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


_init_state()


# === 启动后台研究 ===
def _run_research_thread(topic: str, config: dict) -> None:
    """后台线程入口。异常都会被 storage.mark_failed 接住。"""
    try:
        deep = DeepResearch(output_root=OUTPUT_ROOT, config=config)
        deep.run(topic)
    except Exception as e:  # noqa: BLE001
        logger.exception("后台研究线程崩溃: %s", e)


def _start_research(topic: str, config: dict) -> None:
    st.session_state.research_running = True
    st.session_state.current_rid = None
    threading.Thread(
        target=_run_research_thread,
        args=(topic, config),
        daemon=True,
        name="research-worker",
    ).start()
    logger.info("已启动后台研究 thread: topic=%r", topic)


# === 侧栏: 历史研究 + 配置 ===
def render_sidebar() -> None:
    with st.sidebar:
        st.title("🔬 深度研究助手")

        st.markdown("---")
        st.subheader("📚 历史研究")

        histories = list_histories(OUTPUT_ROOT)
        if not histories:
            st.caption("(暂无历史)")
        else:
            # 显示「最新在前」,前 30 个
            labels = [
                f"[{_status_icon(h['status'])}] {_short_time(h['started_at'])} · {h['topic'][:24]}"
                for h in histories[:30]
            ]
            label_to_idx = {labels[i]: i for i in range(len(labels))}
            default_label = labels[0] if labels else None
            chosen = st.selectbox(
                "选择研究",
                ["(新建)"] + labels,
                index=0 if st.session_state.current_rid is None else _find_history_index(histories, st.session_state.current_rid) + 1,
                key="history_picker",
                label_visibility="collapsed",
            )
            if chosen == "(新建)":
                st.session_state.current_rid = None
            else:
                idx = label_to_idx[chosen]
                st.session_state.current_rid = histories[idx]["dir_name"]

        st.markdown("---")
        with st.expander("⚙️ 环境状态", expanded=False):
            st.caption(f"BOCHA_API_KEY: {'✓' if os.getenv('BOCHA_API_KEY') else '✗ 缺失'}")
            st.caption(f"DEEPSEEK_API_KEY: {'✓' if os.getenv('DEEPSEEK_API_KEY') else '✗ 缺失'}")
            st.caption(f"DEEPSEEK_MODEL: `{os.getenv('DEEPSEEK_MODEL', 'deepseek-v4-flash')}`")
            st.caption(f"输出目录: `{OUTPUT_ROOT}`")

        st.markdown("---")
        st.caption("v1.0 · 综合案例 02 · VibeCoding")


def _status_icon(status: str) -> str:
    return {
        STATUS_PENDING: "⏳",
        STATUS_RUNNING: "🔄",
        STATUS_COMPLETED: "✅",
        STATUS_FAILED: "❌",
    }.get(status, "❓")


def _short_time(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%m-%d %H:%M")
    except Exception:
        return iso[:16] if iso else ""


def _find_history_index(histories: list[dict], rid: str | None) -> int:
    if not rid:
        return -1
    for i, h in enumerate(histories):
        if h["dir_name"] == rid:
            return i
    return -1


# === 表单(无 current_rid 时显示)===
def render_form() -> None:
    st.header("🚀 开始一次新研究")
    st.caption("「深度研究助手」会自动拆解主题、多轮检索、综合生成带来源引用的研究报告。")

    examples = load_examples()
    example_options = ["(自定义)"] + [ex.get("title", "?") for ex in examples]

    col_form, col_meta = st.columns([2, 1])
    with col_form:
        with st.form("research_form", clear_on_submit=False):
            ex_idx = st.selectbox(
                "📋 示例主题(可下拉直接选)",
                range(len(example_options)),
                format_func=lambda i: example_options[i],
                index=st.session_state.selected_example_idx,
            )
            st.session_state.selected_example_idx = ex_idx

            default_topic = ""
            if ex_idx > 0 and ex_idx - 1 < len(examples):
                default_topic = examples[ex_idx - 1].get("topic", "")

            topic = st.text_area(
                "🎯 研究主题",
                value=st.session_state.topic_input or default_topic,
                height=100,
                placeholder="例:2026 年 AI Agent 行业趋势,以及主要技术路线对比",
                help="尽量具体、给出背景与角度,助手会拆解为多个子问题。",
            )

            col_a, col_b = st.columns(2)
            with col_a:
                max_iters = st.slider(
                    "🔁 最大迭代轮数", 1, 10, 5,
                    help="ReAct 循环的最大步数,到点会强制停止。",
                )
            with col_b:
                temperature = st.slider(
                    "🎲 LLM 温度", 0.0, 1.0, 0.3, 0.05,
                    help="越低越稳定,越高越发散。",
                )

            submitted = st.form_submit_button("🚀 开始研究", use_container_width=True, type="primary")
            if submitted:
                topic_clean = (topic or "").strip()
                if not topic_clean:
                    st.error("请输入研究主题。")
                elif not os.getenv("BOCHA_API_KEY"):
                    st.error("BOCHA_API_KEY 未配置,请在 .env 文件设置。")
                elif not os.getenv("DEEPSEEK_API_KEY"):
                    st.error("DEEPSEEK_API_KEY 未配置,请在 .env 文件设置。")
                else:
                    st.session_state.topic_input = topic_clean
                    config = {"max_iterations": int(max_iters), "temperature": float(temperature)}
                    _start_research(topic_clean, config)

    with col_meta:
        st.subheader("💡 使用提示")
        st.markdown(
            """
- **研究过程可观察**:右侧「进度」Tab 实时显示 agent 每一步思考与工具调用。
- **来源可追溯**:每个结论关联 URL,可在「来源」Tab 查看。
- **置信度透明**:综合启发式打分 + LLM 自评,见报告「置信度说明」。
- **历史留存**:每次研究的 4 文件(报告/来源/过程/黑板)都保存到 `output/`。
            """
        )

        st.subheader("📂 产物文件")
        st.markdown(
            """
- `report.md` — 最终报告
- `sources.json` — 来源列表
- `process.json` — 过程摘要
- `findings.json` — 黑板快照
            """
        )


# === Tabs 主体 ===
def render_research_view(rid: str) -> None:
    dir_path = OUTPUT_ROOT / rid
    if not dir_path.exists():
        st.error(f"研究目录不存在: {dir_path}")
        st.session_state.current_rid = None
        return

    storage = ResearchStorage.open(dir_path)
    process = storage.get_process()
    topic = storage.topic

    # 标题区
    status = process.get("status", "?")
    icon = _status_icon(status)
    st.markdown(f"## {icon} {topic}")
    st.caption(
        f"研究 ID: `{rid}` · 状态: **{status}** · 开始: {process.get('started_at', '?')}"
    )

    tab_progress, tab_report, tab_sources, tab_process = st.tabs(
        ["⏳ 进度", "📝 报告", "🔗 来源", "⚙️ 过程"]
    )

    with tab_progress:
        _render_progress_tab(storage)

    with tab_report:
        _render_report_tab(storage)

    with tab_sources:
        _render_sources_tab(storage)

    with tab_process:
        _render_process_tab(storage)


def _render_progress_tab(storage: ResearchStorage) -> None:
    """进度: 时间线 + 来源实时追加 (Q14 D)。"""
    sources = storage.get_sources()
    findings = storage.get_findings()
    process = storage.get_process()
    steps = process.get("steps", [])

    col_left, col_right = st.columns([3, 2])

    with col_left:
        st.subheader("🧠 研究时间线")
        if not steps:
            st.caption("(等待第一步...)")
        else:
            # 取最近 30 步,倒序展示
            for step in reversed(steps[-30:]):
                _render_step_card(step)

    with col_right:
        st.subheader("📚 已发现来源")
        st.caption(f"共 {len(sources)} 条")
        if not sources:
            st.caption("(尚未检索)")
        else:
            for i, src in enumerate(sources, start=1):
                with st.container(border=True):
                    st.markdown(f"**[{i}] [{src.get('title', '?')}]({src.get('url', '#')})**")
                    snip = src.get("snippet") or src.get("summary", "")
                    if snip:
                        st.caption(snip[:160] + ("..." if len(snip) > 160 else ""))

        st.markdown("---")
        st.subheader("🗒️ 黑板(已登记 finding)")
        st.caption(f"共 {len(findings)} 条")
        if not findings:
            st.caption("(agent 尚未登记 finding)")
        else:
            for f in findings[-15:]:
                sid = f.get("source_id")
                conf = f.get("confidence_hint", "?")
                claim = (f.get("claim") or "").strip()
                st.markdown(
                    f"- **#{sid}** ({conf}) {claim[:120]}{'...' if len(claim) > 120 else ''}"
                )


def _render_step_card(step: dict) -> None:
    kind = step.get("kind", "?")
    at = step.get("at", "")

    if kind == "agent_start":
        with st.container(border=True):
            st.markdown(f"**▶️ Agent 启动** · _{at}_")
    elif kind == "agent_end":
        with st.container(border=True):
            st.markdown(f"**⏹️ Agent 结束** · _{at}_")
            preview = step.get("output_preview", "")
            if preview:
                st.caption(preview)
    elif kind == "agent_action":
        with st.container(border=True):
            tool = step.get("tool", "?")
            ti = step.get("tool_input", "")
            thought = step.get("thought_preview", "")
            st.markdown(f"**🧠 第 {step.get('step', '?')} 步 · {tool}** · _{at}_")
            if thought:
                st.caption(f"💭 {thought[:200]}")
            if ti:
                st.caption(f"→ 输入: `{ti[:200]}`")
    elif kind == "tool_start":
        with st.container(border=True):
            st.markdown(f"**🔧 调用 {step.get('tool', '?')}** · _{at}_")
            inp = step.get("input_preview", "")
            if inp:
                st.caption(f"输入: `{inp[:160]}`")
    elif kind == "tool_end":
        with st.container(border=True):
            st.markdown(f"**✓ 工具返回** · _{at}_")
            out = step.get("output_preview", "")
            if out:
                st.caption(f"输出: {out[:160]}...")
    elif kind == "tool_error":
        with st.container(border=True):
            st.markdown(f"**⚠️ 工具错误** · _{at}_")
            st.caption(step.get("error", ""))
    elif kind == "validation_warning":
        with st.container(border=True):
            st.markdown(f"**⚠️ 校验警告** · _{at}_")
            st.caption(step.get("warning", ""))
    elif kind == "final_output":
        with st.container(border=True):
            st.markdown(f"**📤 最终输出** · _{at}_")
    else:
        with st.container(border=True):
            st.markdown(f"**{kind}** · _{at}_")


def _render_report_tab(storage: ResearchStorage) -> None:
    report = storage.get_report()
    if not report:
        st.info("报告尚未生成。研究完成后会出现在这里。")
        return
    st.markdown(report)

    st.download_button(
        "⬇️ 下载 report.md",
        data=report.encode("utf-8"),
        file_name=f"{storage.dir_path.name}.md",
        mime="text/markdown",
        use_container_width=True,
    )


def _render_sources_tab(storage: ResearchStorage) -> None:
    sources = storage.get_sources()
    if not sources:
        st.info("尚无来源。")
        return
    rows = []
    for i, src in enumerate(sources, start=1):
        rows.append(
            {
                "#": i,
                "标题": src.get("title", ""),
                "URL": src.get("url", ""),
                "置信度": src.get("confidence_label", "?"),
                "理由": src.get("confidence_reason", ""),
                "摘要": (src.get("snippet") or src.get("summary", ""))[:120],
            }
        )
    st.dataframe(rows, use_container_width=True, hide_index=True)


def _render_process_tab(storage: ResearchStorage) -> None:
    process = storage.get_process()
    st.subheader("状态机")
    st.json(
        {
            "topic": process.get("topic"),
            "status": process.get("status"),
            "started_at": process.get("started_at"),
            "updated_at": process.get("updated_at"),
            "finished_at": process.get("finished_at"),
            "error": process.get("error"),
            "config": process.get("config"),
            "step_count": len(process.get("steps", [])),
        }
    )
    with st.expander(f"全部过程步骤 ({len(process.get('steps', []))} 条)", expanded=False):
        st.json(process.get("steps", []))

    st.subheader("Findings 黑板")
    st.json(storage.get_findings())


# === 主路由 ===
def main() -> None:
    render_sidebar()

    # 如果有正在运行的研究,自动定位最新 running 的作为 current_rid
    if st.session_state.research_running:
        histories = list_histories(OUTPUT_ROOT)
        running = [h for h in histories if h["status"] == STATUS_RUNNING]
        if running:
            st.session_state.current_rid = running[0]["dir_name"]
            # 1.5s 后刷新页面,拉取最新进度
            time.sleep(1.5)
            st.rerun()
        else:
            # 找最新一条
            if histories:
                st.session_state.current_rid = histories[0]["dir_name"]
            st.session_state.research_running = False
            st.rerun()

    if st.session_state.current_rid:
        render_research_view(st.session_state.current_rid)
        if st.button("← 返回新建研究"):
            st.session_state.current_rid = None
            st.session_state.research_running = False
            st.rerun()
    else:
        render_form()


if __name__ == "__main__":
    main()
