# 深度研究助手 · 综合案例 02

> 输入一个研究主题 → 自动多轮检索 → 综合生成带来源引用的研究报告
> **AI 大模型应用课程 · 第 8 周作业 · VibeCoding 实操**

---

## 一、快速启动

### Windows

```bash
# 1. 双击启动(首次运行会检查 .env 和依赖)
start.bat
```

或者手动:

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
copy .env.example .env
# 用记事本打开 .env,填入 BOCHA_API_KEY 与 DEEPSEEK_API_KEY

# 3. 启动
streamlit run app.py
```

### Mac / Linux

```bash
chmod +x start.sh
./start.sh
```

启动后浏览器自动打开 `http://localhost:8501`。

---

## 二、架构图

```
┌────────────────────────────────────────────────────────────────┐
│                    Streamlit UI (app.py)                        │
│  ┌──────────┐  ┌──────────────────────────────────────────┐    │
│  │ Sidebar  │  │ Form: Topic / Budget / Examples           │    │
│  │ History  │  │ Tabs: ⏳ Progress / 📝 Report / 🔗 Sources │    │
│  └──────────┘  └──────────────────────────────────────────┘    │
└──────────────┬─────────────────────────────────────────────────┘
               │ Threading.Thread(daemon)
               ▼
┌────────────────────────────────────────────────────────────────┐
│               DeepResearch (core/agent.py)                       │
│  ┌──────────────┐    ┌──────────────────────────────────┐       │
│  │  LLM Factory │ →  │   ReAct Agent (create_react_agent) │      │
│  │  ChatOpenAI  │    │   + AgentExecutor                 │      │
│  │  DeepSeek    │    │   max_iterations=5                │      │
│  └──────────────┘    └──────────────────────────────────┘       │
└──────────────┬─────────────────────────────────────────────────┘
               │ Tool calls (sequential ReAct)
               ▼
┌────────────────────────────────────────────────────────────────┐
│                  4 Tools (core/tools.py)                         │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐  │
│  │ web_search │ │ fetch_url  │ │ record_    │ │ extract_   │  │
│  │  (Bocha)   │ │ (Bocha URL)│ │ finding    │ │ facts      │  │
│  └────────────┘ └────────────┘ └────────────┘ └────────────┘  │
└──────────────┬─────────────────────────────────────────────────┘
               │
               ▼
┌────────────────────────────────────────────────────────────────┐
│           Persistence Layer (core/storage.py)                   │
│   output/{时间戳}_{slug}/                                       │
│     ├── report.md       最终报告                                  │
│     ├── sources.json    来源列表                                  │
│     ├── process.json    状态机 + 过程步骤                           │
│     └── findings.json   黑板快照(record_finding 全部条目)        │
└────────────────────────────────────────────────────────────────┘
               ▲
               │ ProgressCallback(BaseCallbackHandler)
               │ on_agent_action / on_tool_*
               │
┌────────────────────────────────────────────────────────────────┐
│           Report Rendering (core/report.py)                     │
│   validate_citations → annotate_sources_with_confidence        │
│   → Jinja2 REPORT_TEMPLATE → Markdown                           │
└────────────────────────────────────────────────────────────────┘
```

---

## 三、目录结构

```
vibecoding/
├── app.py                       # Streamlit 入口
├── start.bat / start.sh         # 启动脚本
├── requirements.txt             # Python 依赖
├── .env.example                 # 环境变量模板
├── .gitignore
├── README.md                    # 本文件
│
├── core/                        # 业务核心
│   ├── __init__.py
│   ├── storage.py               # 持久化 + 状态机
│   ├── prompts.py               # ReAct prompt + Jinja2 报告模板
│   ├── tools.py                 # 4 个 LangChain tool
│   ├── callbacks.py             # ProgressCallback
│   ├── agent.py                 # ReAct 编排 + Final Answer 解析
│   └── report.py                # 引用校验 + 置信度 + 渲染
│
├── configs/
│   └── examples.json            # 5 个示例主题
│
├── output/                      # .gitignore,运行产物
│   └── 2026-09-10_143025_xxx/
│       ├── report.md
│       ├── sources.json
│       ├── process.json
│       └── findings.json
│
└── logs/
    └── app.log                  # 运行日志
```

---

## 四、35 题决策档案(本项目从 Round 1~5 grilling 收敛)

> 这些决策解释了「为什么这样做」,而非「做了什么」。

### Round 1 — 基础形态

| # | 决策 | 选项 | 理由 |
|---|---|---|---|
| Q1 | 交付形态 | **A. Streamlit Web UI** | 进度可视化最佳,迭代最快 |
| Q2 | 技术栈 | **B. LangChain** | 主流,工具调用现成 |
| Q3 | 完成度 | **C. 教学型** | 课程作业展示思考过程更重要 |
| Q4 | 预算 | **B. 中量**(≤5 轮/10 结果/20 精读) | 一次 3-5 分钟,体验合适 |
| Q5 | 持久化 | **B. Markdown + JSON** | 便于查阅和提交 |
| Q6 | 输出形态 | **E. Streamlit 内渲染 + 可下载 .md** | 在线+离线兼得 |
| Q7 | 模型分工 | **A. 全程一个模型** | 简化,降低复杂度 |

### Round 2 — Stack & 行为

| # | 决策 | 选项 | 理由 |
|---|---|---|---|
| Q8 | 具体模型 | **A. DeepSeek**(deepseek-v4-flash) | 历史作业一贯 |
| Q9 | LangChain 范式 | **A. AgentExecutor + ReAct**(不用 LangGraph) | 简单透明 |
| Q10 | 目录结构 | **B. 轻量分层**(core/ + app.py) | 不过度工程 |
| Q11 | 停止条件 | **D. LLM 自评 + 新信息收敛 + 硬上限三重保险** | 客观+主观+兜底 |
| Q12 | 置信度 | **D. 来源数量(基础)+ 域名质量(加权)+ 启发式** | 可解释 |
| Q13 | 搜索策略 | **C. 分面搜索**(每轮拆 N 面,每面 1~2 query) | 拆子问题=规划 |
| Q14 | 进度展示 | **D. 时间线(左)+ 来源实时追加(右)** | 看着 AI 研究 |

### Round 3 — Agent 机制

| # | 决策 | 选项 | 理由 |
|---|---|---|---|
| Q15 | 工具集 | **C. 4 件套**(search/fetch/record/extract) | 黑板 + 子 LLM 抽 |
| Q16 | 网页正文 | **A. 只用 Bocha summary** | 零额外依赖,够用 |
| Q17 | 进度同步 | **B. LangChain CallbackHandler** | 官方机制,不绕开框架 |
| Q18 | 引用机制 | **C. 双保险**(黑板登记 + 最终校验) | 不让 LLM 编来源 |
| Q19 | 报告结构 | **C. 固定外壳 + 章节动态** | 便于渲染,避免千篇一律 |
| Q20 | Context 管理 | **C. 黑板替代历史** | 经典 ReAct 优化 |
| Q21 | 渲染布局 | **D. 主区 markdown + 侧栏元数据** | 信息密度合适 |

### Round 4 — 运维细节

| # | 决策 | 选项 | 理由 |
|---|---|---|---|
| Q22 | 输出目录 | **A. 时间戳 + 主题 slug** | 一眼能看出哪次跑 |
| Q23 | 产物清单 | **B. 四件套**(report/sources/process/findings) | 必要且不冗余 |
| Q24 | 错误处理 | **C. 部分失败容忍** | 跑得通>全失败 |
| Q25 | 并发 | **A. 纯串行 ReAct** | 先稳,再优化 |
| Q26 | DeepSeek 型号 | **C. deepseek-v4-flash** | 你历史验证 |
| Q27 | 环境变量 | **A. 项目根 .env 统一** | 简单 |
| Q28 | 日志 | **C. logging + LangChain verbose** | 看着 AI 思考 |

### Round 5 — 收尾

| # | 决策 | 选项 | 理由 |
|---|---|---|---|
| Q29 | 启动入口 | **D. start.bat + streamlit run app.py** | Windows 友好 |
| Q30 | UI 布局 | **C. 顶部表单 + Tabs** | 信息架构清晰 |
| Q31 | 历史回顾 | **B. 侧栏下拉** | 刚好够用 |
| Q32 | 示例主题 | **B. 下拉 3~5 个** | 降低门槛 |
| Q33 | 提交物 | **C. 源码 + README + 截图** | 与作业 1 一致 |
| Q34 | README 内容 | **C. 启动 + 架构图 + 决策理由** | 既是文档也是思考档案 |
| Q35 | 注释密度 | **D. 章节化 `# === 阶段 ===` + docstring** | 与 LangChain 阶段对应 |

---

## 五、核心流程详解

### 5.1 ReAct 循环(每轮)

```
   ┌────────────┐
   │  Thought   │ → 想下一步:还差什么?搜什么?读什么?
   └─────┬──────┘
         ▼
   ┌────────────┐
   │   Action   │ → 选 1 个工具(web_search / fetch_url /
   └─────┬──────┘    record_finding / extract_facts)
         ▼
   ┌────────────┐
   │ Observation│ → 工具返回结果(格式化文本或 JSON)
   └─────┬──────┘
         ▼
   (回到 Thought,直到满足停止条件)
```

### 5.2 何时停止(三选一)

1. **LLM 自评**:核心子问题已被 ≥2 个独立来源覆盖
2. **新信息收敛**:连续两轮新增 finding < 2 条
3. **硬上限**:达到 `MAX_ROUNDS=5`

### 5.3 置信度算法

| 基础分 | 来源数量 | 加分 | 减分 |
|---|---|---|---|
| high | ≥2 个独立来源 | 权威域名(.gov/.edu/wikipedia) | 低质量域名(SEO/内容农场) |
| medium | 1 个来源 | 一般可信度 | 一般可信度 |
| low | 0 个同向来源 | — | — |

每个来源最终落到 `high / medium / low` 三档,见 `report.md` 的「置信度说明」节。

### 5.4 引用双保险

1. **登记**:agent 必须用 `record_finding(claim, source_id=N)` 写入黑板,`source_id` 来自 web_search 返回的 [N] 编号
2. **校验**:`report.validate_citations` 检查 Final Answer 里所有 `source_id` 是否合法;越界/缺失则剔除并记 warning
3. **标注**:无 source_id 的章节追加 `*(模型推断 — 无来源)*` 后缀

---

## 六、API 与环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `BOCHA_API_KEY` | (必填) | Bocha AI 搜索 key |
| `BOCHA_BASE_URL` | `https://api.bocha.cn/v1/web-search` | Bocha 接口地址 |
| `DEEPSEEK_API_KEY` | (必填) | DeepSeek key |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com/v1` | DeepSeek OpenAI 兼容接口 |
| `DEEPSEEK_MODEL` | `deepseek-v4-flash` | 模型名 |
| `MAX_ROUNDS` | `5` | ReAct 最大迭代 |
| `MAX_SEARCH_PER_ROUND` | `10` | 每轮搜索条数 |
| `MAX_READ_PAGES` | `20` | 最大精读数(预留) |
| `LANGCHAIN_VERBOSE` | `true` | 是否打印 ReAct 推理过程 |
| `LLM_RETRIES` | `3` | LLM 调用重试次数 |
| `LLM_REQUEST_TIMEOUT` | `120` | LLM 调用超时(秒) |

完整模板见 `.env.example`。

---

## 七、运行截图

提交作业时附 2~3 张截图:

1. **首页**:表单 + 5 个示例主题
2. **进度 Tab**:研究进行中的时间线 + 来源列表
3. **报告 Tab**:最终 Markdown 报告渲染

> 截图保存到 `screenshots/` 目录(不入库)。

---

## 八、已知限制与后续可优化

- ❗ 不并发搜索(Q25):同一轮可考虑并行 web_search,提速 2~3 倍
- ❗ 不抓取完整 HTML(Q16):Bocha summary 偶有信息不足,可加 Jina Reader 作 fetch_url 兜底
- ❗ 引用校验是「字符级」:章节里内联的 `[1] [2]` 引用不会二次校验,只在 `source_ids` 字段校验
- ❗ 没有单元测试:核心逻辑可拆出 mock-based 测试,但作业范围内未做
- ❗ 流式输出未启用:LLM 生成过程对用户不可见,只看到 tool 步骤;可加 `streaming=True`

---

<sub>Built with VibeCoding · Round 1~5 design tree</sub>
