#!/usr/bin/env bash
# === 深度研究助手 Unix 启动脚本 ===
set -e
cd "$(dirname "$0")"

if [ ! -f ".env" ]; then
  echo "[警告] 未找到 .env,正在从 .env.example 复制..."
  if [ -f ".env.example" ]; then
    cp ".env.example" ".env"
    echo "[提示] 已生成 .env,请填写 BOCHA_API_KEY 与 DEEPSEEK_API_KEY 后重试。"
    exit 1
  fi
fi

if ! command -v streamlit >/dev/null 2>&1; then
  echo "[提示] 未检测到 streamlit,正在安装依赖..."
  python -m pip install -r requirements.txt
fi

echo "============================================"
echo "  深度研究助手 · 启动中..."
echo "  浏览器将自动打开 http://localhost:8501"
echo "  按 Ctrl+C 可停止服务"
echo "============================================"
streamlit run app.py
